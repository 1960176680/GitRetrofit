package com.example.y.mvp.mvp.Bean;

/**
 * by 12406 on 2016/5/14.
 */
@SuppressWarnings("ALL")
public class TabNewsInfo {

    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
